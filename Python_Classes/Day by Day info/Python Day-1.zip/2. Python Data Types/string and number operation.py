# String concatination
a = ' me'
word = "Help"+ a
print word

word = 'Help' + 'a'

print word

word = word + 'll'

print word

#Numeric variable
a=4
print a

#numeric operation
b=12+5
print b




sum1 = a + b
diff =  b - a
mul = a * b
div = b/a
rem = b%a
flot = float(b)/float(a)

print "sum = ",sum1, " Diff = ", diff
print "mul = ", mul
print "div = ", div, " Rem = ", rem
print "Float div = ", flot